-- LFG Forever - Language Pack Spanish -- Spanish.lua
--
-- DATA ONLY. This file fills this addon's own table (the second vararg the
-- client hands every addon file) with the Spanish words for LFG Forever.
-- LFG Forever's core/locale.lua finds this addon by its TOC field
-- (X-LFGForever-LanguagePack), loads it, and reads this table back with
-- C_AddOns.GetAddOnLocalTable (AllowAddOnTableAccess in the TOC). It runs no
-- code, registers nothing and writes no global.
--
-- Keys are LFG Forever's (addons/LFGForever/core/locale.lua). A key left out,
-- or a value LFG Forever refuses, shows in English. Above each entry is the
-- English it replaces, for reviewers.
--
-- SPANISH AS WRITTEN IN SPAIN (es-ES), a machine-drafted translation awaiting
-- review by a Spanish speaker in the client. Where LFG Forever borrows a word
-- from the game (core/locale.lua's Blizzard(...) keys), the value is Blizzard's
-- own esES text, exactly, so the pack says what a Spanish client in Spain
-- already shows. Two exceptions, where Blizzard's esES is wrong: the Role Check
-- tooltip (esES says the leader cancelled the check) and the activity header's
-- "activididades"; those take the correct wording.
--
-- TRANSLATION RULES (the spec holds this file to them):
--   * keep %s and %d in *_FORMAT values, in the same number and order; no
--     positional %2$s; a literal percent sign is %%;
--   * keep %class%, %level%, %talents%, %role% and %dungeon% as they are, and the
--     names "LFG Forever", "Discord", /lfg;
--   * Settings row labels (*_LABEL under SETTINGS_) fit one line: 28 letters
--     at most;
--   * Latin-1 letters only: á é í ó ú ñ ü ¿ ¡ draw in the client's font, but
--     letters beyond Latin-1 may show as boxes (the Czech pack's č, ř, ů did);
--   * the |4singular:plural; escape is fine where Blizzard's Spanish uses it:
--     Spanish picks its plural the way the client's English rules do (1 is
--     singular, anything else plural);
--   * dungeon, zone and category names are the game's: they stay as the
--     client shows them, and examples quote them that way.
--
-- GLOSSARY: Tanque, Sanador, Daño (Tank / Healer / Damage); función (role);
-- susurro, susurrar (whisper); listado (listing); actividad (activity); filtro,
-- Mis filtros (filter, My filters); mazmorra (dungeon); banda (raid);
-- hermandad (guild); Solicitar unirse (Ask to Join); Buscador de grupos de
-- Blizzard (Blizzard's Group Finder). The player is addressed with "tú", and
-- the recent past is the perfect ("has elegido"), as Blizzard's esES writes.
local _, pack = ...

-- The table layout LFG Forever reads (core/locale.lua, LANGUAGE_PACK_API).
pack.api = 1

-- For people; LFG Forever does not show it yet.
pack.language = "Español"

pack.strings = {

	-- core/main.lua
	-- settings can't be opened during combat.
	COMBAT_SETTINGS = "no se puede abrir la configuración durante el combate.",
	-- %s %s loaded. Type %s
	LOADED_VERSION_FORMAT = "%s %s cargado. Escribe %s",
	-- %s loaded. Type %s
	LOADED_FORMAT = "%s cargado. Escribe %s",

	-- core/relations.lua
	-- Guild Member
	RELATION_GUILD = "Miembro de hermandad",
	-- Friend
	RELATION_FRIEND = "Amigo",

	-- core/settings.lua
	-- Whisper log size
	SETTINGS_WHISPER_LOG_SIZE_LABEL = "Susurros guardados",
	-- How many received whispers the Whispers tab keeps. When there are more, the oldest are removed.
	SETTINGS_WHISPER_LOG_SIZE_TOOLTIP = "Cuántos susurros recibidos guarda la pestaña Susurros. Si hay más, se eliminan los más antiguos.",
	-- Auto-whisper on Ask to Join
	SETTINGS_ASK_TO_JOIN_AUTO_WHISPER_LABEL = "Susurrar al solicitar unirse",
	-- When on, Ask to Join whispers the group leader your message. When off, it opens a whisper so you can type your own.
	SETTINGS_ASK_TO_JOIN_AUTO_WHISPER_TOOLTIP = "Si está activado, Solicitar unirse le susurra tu mensaje al líder del grupo. Si está desactivado, abre un susurro para que escribas el tuyo.",
	-- Message
	SETTINGS_ASK_TO_JOIN_MESSAGE_LABEL = "Mensaje",
	-- %class% and %level% become your class and level. %talents% becomes your active talent tree: the one you have spent the most points in. %role% becomes the roles you selected in Blizzard's Group Finder. %dungeon% becomes the dungeon you are trying to join, in your game's client language. %dungeon_en% becomes the dungeon you are trying to join, in English. Up to 200 characters. Saved for this character.
	SETTINGS_ASK_TO_JOIN_MESSAGE_TOOLTIP = "%class% y %level% se reemplazan por tu clase y tu nivel. %talents% se reemplaza por tu árbol de talentos activo: aquel en el que has gastado más puntos. %role% se reemplaza por las funciones que has elegido en el Buscador de grupos de Blizzard. %dungeon% se reemplaza por la mazmorra a la que intentas unirte, en el idioma de tu cliente del juego. %dungeon_en% se reemplaza por la mazmorra a la que intentas unirte, en inglés. Hasta 200 caracteres. Se guarda para este personaje.",
	-- Placeholders
	SETTINGS_PLACEHOLDERS_TITLE = "Variables",
	-- your class
	SETTINGS_PLACEHOLDER_CLASS = "tu clase",
	-- your level
	SETTINGS_PLACEHOLDER_LEVEL = "tu nivel",
	-- your main talent tree: the one with the most points
	SETTINGS_PLACEHOLDER_TALENTS = "tu árbol de talentos principal: el que tiene más puntos",
	-- the roles you selected in Blizzard's Group Finder
	SETTINGS_PLACEHOLDER_ROLE = "las funciones que has elegido en el Buscador de grupos de Blizzard",
	-- the dungeon you are trying to join, in your game's client language
	SETTINGS_PLACEHOLDER_GROUP_DUNGEON = "la mazmorra a la que intentas unirte, en el idioma de tu cliente del juego",
	-- the dungeon you are trying to join, in English
	SETTINGS_PLACEHOLDER_GROUP_DUNGEON_EN = "la mazmorra a la que intentas unirte, en inglés",
	-- Auto-whisper on Invite
	SETTINGS_INVITE_AUTO_WHISPER_LABEL = "Susurrar al invitar",
	-- When on, inviting a player from the players list also whispers them your message. When off, it only invites.
	SETTINGS_INVITE_AUTO_WHISPER_TOOLTIP = "Si está activado, al invitar a un jugador desde la lista de jugadores también le susurras tu mensaje. Si está desactivado, solo lo invitas.",
	-- Message
	SETTINGS_INVITE_MESSAGE_LABEL = "Mensaje",
	-- %dungeon% becomes the dungeon of your listing in your game's client language, or all of them if it has several ("Deadmines, Wailing Caverns or Shadowfang Keep"). With no listing, it becomes the activities selected in the activity filter. %dungeon_en% becomes the dungeons of your listing in English, or with no listing, the activities selected in the activity filter. Up to 200 characters. Saved for this character.
	SETTINGS_INVITE_MESSAGE_TOOLTIP = "%dungeon% se reemplaza por la mazmorra de tu listado en el idioma de tu cliente del juego, o por todas si tiene varias (\"Deadmines, Wailing Caverns or Shadowfang Keep\"). Sin listado, se reemplaza por las actividades seleccionadas en el filtro de actividades. %dungeon_en% se reemplaza por las mazmorras de tu listado en inglés o, sin listado, por las actividades seleccionadas en el filtro de actividades. Hasta 200 caracteres. Se guarda para este personaje.",
	-- the dungeons of your listing in your game's client language, or with no listing, the activities selected in the activity filter
	SETTINGS_PLACEHOLDER_DUNGEON = "las mazmorras de tu listado en el idioma de tu cliente del juego o, sin listado, las actividades seleccionadas en el filtro de actividades",
	-- the dungeons of your listing in English, or with no listing, the activities selected in the activity filter
	SETTINGS_PLACEHOLDER_DUNGEON_EN = "las mazmorras de tu listado en inglés o, sin listado, las actividades seleccionadas en el filtro de actividades",
	-- Search
	SETTINGS_SEARCH_HEADER = "Búsqueda",
	-- Show all level activities
	SETTINGS_SHOW_ALL_LEVELS_LABEL = "Actividades de todo nivel",
	-- Show activities for every dungeon and raid, not only the ones suggested for your level.
	SETTINGS_SHOW_ALL_LEVELS_TOOLTIP = "Muestra actividades de todas las mazmorras y bandas, no solo las sugeridas para tu nivel.",
	-- Show suggested level ranges
	SETTINGS_SHOW_LEVEL_RANGES_LABEL = "Mostrar niveles sugeridos",
	-- Show each activity's suggested level range after its name in the activity dropdown, for example Deadmines (17 - 24).
	SETTINGS_SHOW_LEVEL_RANGES_TOOLTIP = "Muestra el rango de niveles sugerido de cada actividad después de su nombre en el menú de actividades, por ejemplo Deadmines (17 - 24).",
	-- Mark guild members
	SETTINGS_MARK_GUILDMATES_LABEL = "Marcar a tu hermandad",
	-- Show a guild icon beside guildmates and list them first.
	SETTINGS_MARK_GUILDMATES_TOOLTIP = "Muestra un icono de hermandad junto a los miembros de tu hermandad y los pone primero en la lista.",
	-- Mark friends
	SETTINGS_MARK_FRIENDS_LABEL = "Marcar a tus amigos",
	-- Show a friends icon beside your WoW and Battle.net friends and list them first.
	SETTINGS_MARK_FRIENDS_TOOLTIP = "Muestra un icono de amigo junto a tus amigos de WoW y Battle.net y los pone primero en la lista.",
	-- Sort players by
	SETTINGS_PLAYER_SORT_LABEL = "Ordenar jugadores por",
	-- How players are ordered in the Players list. Your own listing comes first, then friends, players you rated 3 stars and guild members. Players you rated 1 star come last.
	SETTINGS_PLAYER_SORT_PARTS_TOOLTIP = "Cómo se ordenan los jugadores en la lista Jugadores. Tu propio listado va primero y después tus amigos, los jugadores que has valorado con 3 estrellas y los miembros de tu hermandad. Los jugadores que has valorado con 1 estrella van al final.",
	-- Newest listings
	PLAYER_SORT_NEWEST = "Listados más nuevos",
	-- New listings at the top.
	PLAYER_SORT_NEWEST_TOOLTIP = "Los listados nuevos, arriba.",
	-- Oldest listings
	PLAYER_SORT_OLDEST = "Listados más antiguos",
	-- The longest-listed players at the top.
	PLAYER_SORT_OLDEST_TOOLTIP = "Arriba, los jugadores que llevan más tiempo en la lista.",
	-- Highest level
	PLAYER_SORT_LEVEL_HIGH = "Nivel más alto",
	-- Higher levels at the top.
	PLAYER_SORT_LEVEL_HIGH_TOOLTIP = "Los niveles más altos, arriba.",
	-- Lowest level
	PLAYER_SORT_LEVEL_LOW = "Nivel más bajo",
	-- Lower levels at the top.
	PLAYER_SORT_LEVEL_LOW_TOOLTIP = "Los niveles más bajos, arriba.",
	-- Class
	PLAYER_SORT_CLASS = "Clase",
	-- Listings grouped by class.
	PLAYER_SORT_CLASS_TOOLTIP = "Listados agrupados por clase.",
	-- Open LFG Forever
	BINDING_OPEN_WINDOW = "Abrir LFG Forever",
	-- Keybindings (Blizzard's esES SETTINGS_KEYBINDINGS_LABEL)
	KEYBINDINGS = "Atajos de teclado",
	-- Set the key on Blizzard's Keybindings page.
	SETTINGS_KEYBINDING_TOOLTIP = "Asigna la tecla en la página Atajos de teclado de Blizzard.",
	-- Player ratings
	PLAYER_RATINGS = "Valoraciones de jugadores",
	-- Rate recent allies on how they behaved and played, so next time you know who to invite and who to avoid.
	SETTINGS_PLAYER_RATINGS_TOOLTIP = "Valora a tus aliados recientes según cómo se han comportado y cómo han jugado, para saber la próxima vez a quién invitar y a quién evitar.",
	-- Show minimap button
	SETTINGS_MINIMAP_BUTTON_LABEL = "Mostrar botón del minimapa",
	-- Show a button on the edge of the minimap that opens and closes LFG Forever. Drag it to move it. /lfg works either way.
	SETTINGS_MINIMAP_BUTTON_TOOLTIP = "Muestra en el borde del minimapa un botón que abre y cierra LFG Forever. Arrástralo para moverlo. /lfg funciona de todos modos.",
	-- LFG Forever is also available in other languages. Each one is a separate addon on CurseForge, for example "%s".
	SETTINGS_LANGUAGE_PACKS_FORMAT = "LFG Forever también está disponible en otros idiomas. Cada uno es un addon aparte en CurseForge, por ejemplo \"%s\".",
	-- Found a bug or have an idea?
	SETTINGS_REPORT_BUG_LABEL = "¿Un error o una idea?",
	-- Tell us on Discord.
	SETTINGS_REPORT_BUG_TOOLTIP = "Cuéntanos en Discord.",
	-- Copy the link with Ctrl+C and paste it into your browser.
	REPORT_BUG_POPUP_TEXT = "Copia el enlace con Ctrl+C y pégalo en tu navegador.",
	-- Report a bug
	REPORT_BUG = "Informar de un error",
	-- Window position and size
	SETTINGS_RESET_WINDOW_LABEL = "Ventana: posición y tamaño",
	-- Move the LFG Forever window back to where it first opened, at its original size.
	SETTINGS_RESET_WINDOW_TOOLTIP = "Devuelve la ventana de LFG Forever a donde se abrió por primera vez, con su tamaño original.",
	-- Miscellaneous
	MISCELLANEOUS = "Miscelánea",
	-- Reset
	RESET = "Reiniciar",
	-- Close
	CLOSE = "Cerrar",

	-- core/listpanel.lua
	-- Ask to Join
	ASK_TO_JOIN = "Solicitar unirse",
	-- Ask to join again
	ASK_TO_JOIN_AGAIN = "Solicitar unirse otra vez",
	-- Group Invite
	GROUP_INVITE = "Invitar al grupo",
	-- Lvl
	LEVEL_ABBR = "Niv",
	-- %d |4activity:activities;
	ACTIVITY_COUNT_FORMAT = "%d |4actividad:actividades;",
	-- Searching...
	SEARCHING = "Buscando...",
	-- Players
	LIST_DIVIDER_PLAYERS = "Jugadores",
	-- Groups
	LIST_DIVIDER_GROUPS = "Grupos",
	-- Collapse the Groups list
	LIST_COLLAPSE_GROUPS = "Contraer la lista de grupos",
	-- Collapse the Players list
	LIST_COLLAPSE_PLAYERS = "Contraer la lista de jugadores",
	-- Expand the Groups list
	LIST_EXPAND_GROUPS = "Desplegar la lista de grupos",
	-- Expand the Players list
	LIST_EXPAND_PLAYERS = "Desplegar la lista de jugadores",
	-- No groups found. If you can't find what you're looking for, consider starting a group.
	NO_RESULTS = "No se han encontrado grupos. Si no encuentras lo que estás buscando, podrías crear un grupo nuevo.",
	-- Search Failed. Please wait a moment and try again.
	SEARCH_FAILED = "Error al buscar. Espera unos instantes e inténtalo de nuevo.",

	-- core/whisperlog.lua
	-- Whispers
	WHISPERS_TAB_TITLE = "Susurros",
	-- Messages from players
	WHISPERS_SECTION_TITLE = "Mensajes de jugadores",
	-- Location
	LOCATION = "Ubicación",
	-- No whispers yet.
	NO_WHISPERS = "Aún no hay susurros.",
	-- Remove
	REMOVE = "Quitar",
	-- Invite
	INVITE = "Invitar",
	-- ...
	CONTINUED = "...",

	-- core/playerratings.lua
	-- Recent allies
	RECENT_ALLIES_SECTION_TITLE = "Aliados recientes",
	-- No recent allies yet.
	NO_RECENT_ALLIES = "Aún no tienes aliados recientes.",
	-- Recent Allies are not available.
	RECENT_ALLIES_UNAVAILABLE = "Los aliados recientes no están disponibles.",
	-- Open %s > %s to load your allies. (Friends, Recent Allies)
	RECENT_ALLIES_NOT_READY_FORMAT = "Abre %s > %s para cargar tus aliados.",
	-- Friends
	FRIENDS = "Amigos",
	-- Recent Allies
	RECENT_ALLIES = "Aliados recientes",
	-- Recent Activities
	RECENT_ACTIVITIES = "Actividades recientes",
	-- %s ago
	RECENT_ALLY_TIME_FORMAT = "Hace %s",
	-- Level %d  %s  %s (the level, a divider, the race)
	RECENT_ALLY_LEVEL_RACE_FORMAT = "Nivel %d %s %s",
	-- the note icon, then %s
	RECENT_ALLY_NOTE_FORMAT = "|TInterface\\FriendsFrame\\UI-FriendsFrame-Note:0:0:0:0:1:1:0:1:0:1:255:209:0|t %s",
	-- core/playerratings.lua: a player from LFG Forever's own list of the last
	-- party members, on top of the tab.
	-- Grouped Together (the activity on their second line and in their tooltip)
	PARTY_MEMBER_ACTIVITY = "Agrupados juntos",
	-- Level %d (the tooltip's level line)
	PARTY_MEMBER_LEVEL_FORMAT = "Nivel %d",
	-- %s joined your party. You rated the player 1 star %s. (a chat line; the
	-- first %s is the name, the second the gold star icon, after "1 star")
	PARTY_ONE_STAR_JOINED_FORMAT = "%s se ha unido a tu grupo. Has valorado a este jugador con 1 estrella %s.",
	-- core/playerratings.lua: the rating stars' tooltip, its first line drawn as
	-- the tooltip's title, then one line per rating.
	-- Rated players are marked in red, silver or green in the LFG player listings and the Whispers tab.
	PLAYER_RATING_MARKED = "Los jugadores valorados aparecen marcados en rojo, plateado o verde en las listas de jugadores de LFG y en la pestaña \"Susurros\".",
	-- 1 star - I don't want to group with this player
	PLAYER_RATING_ONE_STAR_LINE = "1 estrella - no quiero agruparme con este jugador",
	-- 2 stars - I'm fine grouping with this player
	PLAYER_RATING_TWO_STARS_LINE = "2 estrellas - me parece bien agruparme con este jugador",
	-- 3 stars - I want to group with this player
	PLAYER_RATING_THREE_STARS_LINE = "3 estrellas - quiero agruparme con este jugador",
	-- core/playerratings.lua: Clear player rating, the link, the popup it opens
	-- and the chat line once a rating is cleared. Each %s is the player's name.
	-- Clear player rating (the link on the Recent allies title line)
	CLEAR_PLAYER_RATING = "Borrar valoración de jugador",
	-- Enter the player's character name: (the popup's label)
	CLEAR_PLAYER_RATING_PROMPT = "Escribe el nombre del personaje del jugador:",
	-- Type a player's name. (why Okay is off: the box is empty)
	CLEAR_PLAYER_RATING_EMPTY = "Escribe el nombre de un jugador.",
	-- No rating saved for "%s". (why Okay is off: nobody rated that name)
	CLEAR_PLAYER_RATING_UNKNOWN_FORMAT = "No hay ninguna valoración guardada para \"%s\".",
	-- rating for "%s" cleared. (after "LFG Forever: ")
	PLAYER_RATING_CLEARED_FORMAT = "valoración de \"%s\" borrada.",

	-- core/rateleavers.lua
	-- Players left your party. Do you want to rate them? %s
	RATE_LEAVERS_FORMAT = "Algunos jugadores han dejado tu grupo. ¿Quieres valorarlos? %s",
	-- Rate them
	RATE_LEAVERS_LINK = "Valorarlos",
	-- turn on %s in the settings to rate players.
	RATE_LEAVERS_TURNED_OFF_FORMAT = "activa %s en la configuración para valorar jugadores.",

	-- core/filterpanel.lua
	-- Find players by role and level
	ROLE_SECTION_TITLE = "Buscar jugadores por función y nivel",
	-- Find players by class
	CLASS_SECTION_TITLE = "Buscar jugadores por clase",
	-- Find groups by role
	GROUP_SECTION_TITLE = "Buscar grupos por función",
	-- Filters still apply
	COLLAPSED_FILTERS_TITLE = "Los filtros siguen activos",
	-- This section is collapsed, but its filters are still used in your search.
	COLLAPSED_FILTERS_TOOLTIP = "Esta sección está contraída, pero sus filtros se siguen usando en tu búsqueda.",
	-- Filters
	FILTERS_TAB_TITLE = "Filtros",
	-- Reset filters
	RESET_FILTERS = "Reiniciar filtros",
	-- Unselect all
	UNSELECT_ALL = "Desmarcar todo",
	-- Select all
	SELECT_ALL = "Marcar todo",
	-- Clear chat
	CLEAR_CHAT = "Borrar susurros",
	-- Player level range
	LEVEL_RANGE_LABEL = "Nivel de los jugadores",
	-- My filters
	MY_FILTERS = "Mis filtros",
	-- Save new filter
	SAVE_NEW_FILTER = "Guardar filtro nuevo",
	-- Playstyle
	PLAYSTYLE_ROW_LABEL = "Estilo de juego",
	-- All
	PLAYSTYLE_ALL = "Todo",
	-- %d selected
	PLAYSTYLES_SELECTED_FORMAT = "%d seleccionados",
	-- Languages
	LANGUAGES_ROW_LABEL = "Idiomas",
	-- All
	LANGUAGES_ALL = "Todo",
	-- %d selected
	LANGUAGES_SELECTED_FORMAT = "%d seleccionados",
	-- Default languages are locked by Blizzard. They are always searched and can't be unselected.
	LANGUAGE_LOCKED_BY_BLIZZARD_TOOLTIP = "Los idiomas predeterminados están bloqueados por Blizzard. Siempre se buscan y no se pueden desmarcar.",
	-- No languages available.
	LANGUAGES_NONE_AVAILABLE = "No hay idiomas disponibles.",
	-- German
	LANGUAGE_NAME_DEDE = "Alemán",
	-- English
	LANGUAGE_NAME_ENUS = "Inglés",
	-- Spanish (EU)
	LANGUAGE_NAME_ESES = "Castellano (Europa)",
	-- Spanish (Latin American)
	LANGUAGE_NAME_ESMX = "Español (América Latina)",
	-- French
	LANGUAGE_NAME_FRFR = "Francés",
	-- Italian
	LANGUAGE_NAME_ITIT = "Italiano",
	-- Korean
	LANGUAGE_NAME_KOKR = "Coreano",
	-- Portuguese
	LANGUAGE_NAME_PTBR = "Portugués",
	-- Russian
	LANGUAGE_NAME_RURU = "Ruso",
	-- Chinese (Simplified)
	LANGUAGE_NAME_ZHCN = "Chino simplificado",
	-- Chinese (Traditional)
	LANGUAGE_NAME_ZHTW = "Chino tradicional",
	-- Tank
	ROLE_TANK = "Tanque",
	-- Healer
	ROLE_HEALER = "Sanador",
	-- Damage
	ROLE_DAMAGE = "Daño",
	-- Warrior. The class names are the game's Spanish ones; the client builds
	-- them itself (LOCALIZED_CLASS_NAMES_MALE), so no dumped string lists them.
	CLASS_WARRIOR = "Guerrero",
	-- Paladin
	CLASS_PALADIN = "Paladín",
	-- Hunter
	CLASS_HUNTER = "Cazador",
	-- Rogue
	CLASS_ROGUE = "Pícaro",
	-- Priest
	CLASS_PRIEST = "Sacerdote",
	-- Shaman
	CLASS_SHAMAN = "Chamán",
	-- Mage
	CLASS_MAGE = "Mago",
	-- Warlock
	CLASS_WARLOCK = "Brujo",
	-- Druid
	CLASS_DRUID = "Druida",
	-- Tank role available
	GROUP_TANK_AVAILABLE = "Necesita tanque",
	-- Healer role available
	GROUP_HEALER_AVAILABLE = "Necesita sanador",
	-- Damage role available
	GROUP_DAMAGE_AVAILABLE = "Necesita daño",
	-- Has tank
	GROUP_HAS_TANK = "Tiene tanque",
	-- Has healer
	GROUP_HAS_HEALER = "Tiene sanador",
	-- No groups with...
	GROUP_CLASSES_NONE = "Sin grupos con...",
	-- No %s
	GROUP_CLASSES_ONE_FORMAT = "Sin %s",
	-- No %d classes
	GROUP_CLASSES_COUNT_FORMAT = "Sin %d clases",
	-- Show groups without chosen classes.
	GROUP_CLASSES_TOOLTIP = "Mostrar grupos sin las clases elegidas.",
	-- Show groups without %s.
	GROUP_CLASSES_EXCLUDED_TOOLTIP_FORMAT = "Mostrar grupos sin %s.",
	-- ", " (between the classes in the sentence above)
	GROUP_CLASSES_LIST_SEPARATOR = ", ",
	-- " or " (before the last class)
	GROUP_CLASSES_LIST_LAST_SEPARATOR = " ni ",
	-- Warriors
	CLASS_PLURAL_WARRIOR = "Guerreros",
	-- Paladins
	CLASS_PLURAL_PALADIN = "Paladines",
	-- Hunters
	CLASS_PLURAL_HUNTER = "Cazadores",
	-- Rogues
	CLASS_PLURAL_ROGUE = "Pícaros",
	-- Priests
	CLASS_PLURAL_PRIEST = "Sacerdotes",
	-- Shamans
	CLASS_PLURAL_SHAMAN = "Chamanes",
	-- Mages
	CLASS_PLURAL_MAGE = "Magos",
	-- Warlocks
	CLASS_PLURAL_WARLOCK = "Brujos",
	-- Druids
	CLASS_PLURAL_DRUID = "Druidas",
	-- None
	CATEGORY_NONE = "Nada",
	-- (%d)
	LEVEL_SINGLE_FORMAT = "(%d)",
	-- (%d - %d)
	LEVEL_RANGE_FORMAT = "(%d - %d)",
	-- Search
	SEARCH = "Buscar",
	-- Search Again
	SEARCH_AGAIN = "Buscar otra vez",
	-- Name your new filter:
	MY_FILTER_PROMPT = "Ponle un nombre a tu filtro nuevo:",
	-- My filters holds up to %d filters. Delete one to save a new filter.
	MY_FILTERS_FULL_FORMAT = "Mis filtros guarda hasta %d filtros. Elimina uno para guardar uno nuevo.",
	-- Type a name for your new filter.
	MY_FILTER_EMPTY = "Escribe un nombre para tu filtro nuevo.",
	-- Use at most %d letters.
	MY_FILTER_TOO_LONG_FORMAT = "Usa como máximo %d letras.",
	-- You already have a filter named "%s". It will be overwritten.
	MY_FILTER_OVERWRITE_WARNING_FORMAT = "Ya tienes un filtro llamado \"%s\". Se sobrescribirá.",
	-- filter "%s" saved.
	MY_FILTER_SAVED_FORMAT = "filtro \"%s\" guardado.",
	-- filter "%s" overwritten.
	MY_FILTER_OVERWRITTEN_FORMAT = "filtro \"%s\" sobrescrito.",
	-- filter "%s" applied. Click Search to use it.
	MY_FILTER_APPLIED_FORMAT = "filtro \"%s\" aplicado. Haz clic en Buscar para usarlo.",
	-- filter "%s" deleted.
	MY_FILTER_DELETED_FORMAT = "filtro \"%s\" eliminado.",
	-- Okay
	OKAY = "Aceptar",
	-- Cancel
	CANCEL = "Cancelar",
	-- Delete
	DELETE = "Eliminar",
	-- Role Check
	ROLE_CHECK = "Comprobación de función",
	-- Only your group leader can initiate a Role Check. (Not Blizzard's esES,
	-- which says the leader cancelled the check: the esMX wording.)
	ROLE_CHECK_ONLY_LEADER = "Solo el líder de tu grupo puede iniciar una comprobación de función.",
	-- Settings
	SETTINGS = "Configuración",
	-- Filter by activity
	ACTIVITY_HEADER_DEFAULT = "Filtrar por actividad",
	-- %d |4activity:activities; selected (Blizzard's esES, its typo
	-- "activididades" corrected)
	ACTIVITY_HEADER_FORMAT = "%d |4actividad seleccionada:actividades seleccionadas;",
	-- Set Favorite
	SET_FAVORITE = "Establecer favorito",
	-- Remove Favorite
	REMOVE_FAVORITE = "Eliminar favorito",
	-- Favorites are listed at the top of this list.
	FAVORITES_LISTED_AT_TOP = "Los favoritos aparecen al principio de esta lista.",
	-- %s is no longer offered at your level and was unselected. If you still want to join %s, turn on "%s" in the settings.
	ACTIVITY_NO_LONGER_OFFERED_FORMAT = "%s ya no se ofrece para tu nivel y se ha desmarcado. Si aún quieres unirte a %s, activa \"%s\" en la configuración.",
	-- %s are no longer offered at your level and were unselected. If you still want to join them, turn on "%s" in the settings.
	ACTIVITIES_NO_LONGER_OFFERED_FORMAT = "%s ya no se ofrecen para tu nivel y se han desmarcado. Si aún quieres unirte a ellas, activa \"%s\" en la configuración.",
	-- ", " (between the activities in the sentence above)
	ACTIVITY_LIST_SEPARATOR = ", ",
	-- " and " (before the last one)
	ACTIVITY_LIST_LAST_SEPARATOR = " y ",
	-- %d more (after three names: "A, B, C and 2 more")
	ACTIVITY_LIST_MORE_FORMAT = "%d más",
	-- Category
	CATEGORY = "Categoría",

	-- core/window.lua
	-- the group finder can't be opened during combat.
	COMBAT_WINDOW = "no se puede abrir el buscador de grupos durante el combate.",
	-- Create Listing
	TAB_CREATE_LISTING = "Crear actividad",
	-- Group Browser
	TAB_GROUP_BROWSER = "Buscador de grupo",
	-- Who List
	TAB_WHO_LIST = "Lista de personas",

	-- core/minimap.lua
	-- Left-click to open or close.
	MINIMAP_LEFT_CLICK = "Haz clic izquierdo para abrir o cerrar.",
	-- Right-click for settings.
	MINIMAP_RIGHT_CLICK = "Haz clic derecho para abrir la configuración.",
	-- Drag to move.
	MINIMAP_DRAG = "Arrastra para mover.",
}
