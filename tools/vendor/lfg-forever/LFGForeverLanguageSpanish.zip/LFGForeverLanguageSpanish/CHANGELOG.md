# Changelog

## 2.4.0

- Translated LFG Forever's new favorite star in the activity dropdown: its "Set Favorite" and "Remove Favorite" tooltip, and the line that explains favorites.

## 2.3.0

- Translated LFG Forever's new Ask to Join message texts (`%dungeon%` and `%dungeon_en%` in the "?" help and the tooltip), and the Invite message's fuller `%dungeon_en%` texts.

## 2.2.0

- Translated LFG Forever's new Invite message texts: `%dungeon_en%` in the "?" help, and the tooltip, which now says `%dungeon%` uses your game's language.

## 2.1.0

- Translated LFG Forever's new texts: the Languages filter's tooltip on locked languages, the chat line when a dungeon you outlevelled is unticked, and the My filters warning and chat line when a filter is overwritten.

## 1.5.0

- Translated LFG Forever's new Player ratings: the Player ratings tab and its setting, the rating stars, Clear player rating, and the chat lines about players who join or leave your party. The "Sort players by" tooltip also explains the new order, with friends first.

## 1.4.0

- Translated LFG Forever's new "Ask to join again" tooltip on groups you've already asked.

## 1.3.0

- Translated LFG Forever's new Report a bug button at the top of its window.

## 1.2.0

- No changes to the translation. The version follows LFG Forever's.

## 1.1.0

- Translated LFG Forever's new tooltips on the Groups and Players list headers.

## 0.33.0 (beta)

- Translated LFG Forever's new sentence on the settings page about where to find other languages.

## 0.32.0 (beta)

- No changes to the translation. The version follows LFG Forever's.

## 0.31.0 (beta)

- No changes to the translation. The version follows LFG Forever's.

## 0.30.0 (beta)

- No changes to the translation. The version follows LFG Forever's.

## 0.29.0 (beta)

- Translated LFG Forever's new class filter for groups ("Sin grupos con...").

## 0.28.0 (beta)

- Translated the new Keybindings button in LFG Forever's settings ("Atajos de teclado").

## 0.27.0 (beta)

- Translated LFG Forever's new "Sort players by" setting ("Ordenar jugadores por").

## 0.26.0 (beta)

- New: LFG Forever in Spanish, as written in Spain. Every word LFG Forever shows is translated: the window, the Filters and Whispers tabs, the players list, the tooltips, the settings page and the chat lines. Words LFG Forever borrows from the game (Search, Role Check, Tank, the language names...) use Blizzard's own Spanish from its Spain client. Needs LFG Forever 0.16.0 or later. Enable this addon in the AddOns list to see LFG Forever in Spanish; disable it to go back to English.
- The whispers LFG Forever sends to other players (Ask to Join and Invite) stay in English, so every player can read them. Dungeon, zone and category names stay in your game's language.
